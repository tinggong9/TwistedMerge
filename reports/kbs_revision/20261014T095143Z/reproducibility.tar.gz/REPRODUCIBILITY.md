# TwistedMerge KBS CPU reproducibility package

This is a private-path-sanitized export, not an anonymous submission. Public
repository identity and full provenance remain visible. The author master
archive remains unchanged in the repository. No checkpoint tensors, secrets,
personal cache directories or licensed model weights are included.

Code source commit: 625a15d190ad0e95c53516dc32e659a999e12371.
Starting public snapshot: b0e1ac47e4b0d7c559f37ba8bc3634ba18f3ca1c.

New baseline/certificate checks and raw legacy CSVs/configs are included.
To reproduce all history-dependent inventory checks, clone the public repository
and check out the starting public snapshot, then overlay this package. Its
local code commit was not pushed. A standalone extraction can run the baseline,
certificate and protocol tests, but cannot verify unavailable Git ancestry or
restore omitted checkpoints. Source receipts explicitly retain those limits.

Use Python 3.12 and the included environment.lock.txt, or the author's existing
isolated .venv. See configs/kbs_revision/README.md for CLI commands. Run into a
fresh directory; do not overwrite the delivered run. Model pilot/freeze/run
remain blocked because the neural backend/cohort/splits are unavailable.

export_manifest.csv hashes the exported bytes. author_original_sha256 preserves
the master file hash; existing report manifests/source-hash fields refer to
author bytes before private-path sanitization. Sanitized command/path strings
are provenance records, not executable instructions. Algebra/CSV numeric values
are unchanged. Tensor hashing/loading claims cannot be rechecked without the
omitted historical checkpoints. CPU fixtures are not trained neural results.

# Anonymous backend review package

Direct author paths/names/project URLs and author Git revision identities are
redacted. Public third-party model/code pins, reviewed tensor excerpts and
licenses are preserved. The author master archive is unchanged. Exported files
are read-only. No checkpoint weights, credentials or private cache are included.
Stored software weights were locally generated; they can be recreated from
the deterministic fixture recipe instead of shipped here.

Review numerical results in reports/kbs_revision/20261014T102546Z. These are
software-only random two-block model tests. The real Qwen research pilot is
blocked. They do not establish neural decision utility, power or risk control.

For an independent fresh software replay, use Python3.12 and the supplied
environment.lock.txt, with the source layout at the package root:

python experiments/kbs_revision.py backend-smoke --out <new-scratch-directory>
python -m pytest -q tests/test_kbs_revision_baselines.py tests/test_kbs_revision_certificates.py tests/test_kbs_revision_protocol.py tests/test_kbs_revision_task_data.py tests/test_kbs_revision_external_methods.py tests/test_kbs_revision_language_backend.py tests/test_kbs_revision_neural_runner.py tests/test_kbs_revision_resources.py tests/test_kbs_revision_integration.py

Historical inventory/report tests require the author's legacy raw artifacts
and Git ancestry and are not claimed standalone. Do not resume sanitized
stored episodes: paths/revision labels and source receipts were intentionally
redacted. Original recorded hashes refer to author bytes; export_manifest.csv
hashes the actual exported bytes and records corresponding author-file SHA256.
Fresh replays regenerate new valid manifests/weights and their own receipts.
